advancement grant @p only french_bread:croissant/missing_piece
summon item ~ ~ ~ {Item:{id:"minecraft:gunpowder",count:8}}
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:gray_dye"}}]
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:orange_dye"}}]