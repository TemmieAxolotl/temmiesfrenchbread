advancement grant @p only french_bread:croissant/soup_kitchen
summon item ~ ~ ~ {Item:{id:"minecraft:mushroom_stew",components:{food:{nutrition:12,saturation:14},custom_name:{text:"Flower Stew",italic:false}}}}
setblock ~ ~ ~ cauldron
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:lime_dye"}}]
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:poppy"}}]
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:dandelion"}}]
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:bowl"}}]