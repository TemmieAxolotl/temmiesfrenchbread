#use for testing advancements or playtesting with advancements
scoreboard players reset @s
advancement revoke @s everything