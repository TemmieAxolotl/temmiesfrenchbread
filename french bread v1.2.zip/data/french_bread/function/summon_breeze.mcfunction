summon breeze ~ ~ ~
scoreboard players add @p summons 1
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:snowball"}}]