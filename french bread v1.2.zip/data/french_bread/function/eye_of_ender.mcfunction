#advancement grant @p only french_bread:croissant/soup_kitchen
summon item ~ ~ ~ {Item:{id:"minecraft:ender_eye"}}
setblock ~ ~ ~ cauldron
execute if block ~ ~-1 ~ magma_block run setblock ~ ~-1 ~ cobblestone
execute if block ~ ~-1 ~ lava run setblock ~ ~-1 ~ obsidian
execute if block ~ ~-1 ~ lava_cauldron run setblock ~ ~-1 ~ cauldron
execute if block ~ ~-1 ~ #french_bread:hot_things run setblock ~ ~-1 ~ air
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:blaze_powder"}}]
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:ender_pearl"}}]
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:wind_charge"}}]
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:orange_dye"}}]