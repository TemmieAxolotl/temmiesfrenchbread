summon cow ~ ~ ~
setblock ~ ~-1 ~ coarse_dirt
scoreboard players add @p summons 1
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:wheat"}}]