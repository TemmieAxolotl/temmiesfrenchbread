execute if dimension minecraft:the_nether run advancement grant @p only french_bread:fougasse/your_new_home
summon pig ~ ~ ~
setblock ~ ~-1 ~ coarse_dirt
scoreboard players add @p summons 1
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:beetroot"}}]