advancement grant @p only french_bread:fougasse/ultimate_freezer
summon item ~ ~ ~ {Item:{id:"minecraft:obsidian"}}
summon item ~ ~ ~ {Item:{id:"minecraft:bucket"}}
setblock ~ ~ ~ cauldron
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:lava_bucket"}}]