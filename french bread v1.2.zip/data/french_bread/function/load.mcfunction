execute as @a run execute run attribute @s minecraft:max_health base set 16
gamerule natural_health_regeneration false

scoreboard objectives add summons dummy Summons
#numbers
scoreboard objectives add constant dummy constant
scoreboard players set one constant 1
scoreboard players set hundred constant 100