#give grass if block below is not coarse dirt
summon item ~ ~ ~ {Item:{id:"minecraft:short_grass"}}

#slurp nutrients from surrounding blocks
execute unless block ~ ~-1 ~ coarse_dirt run fill ~-1 ~-1 ~-1 ~1 ~1 ~1 coarse_dirt replace #french_bread:blocks_with_nutrients
execute unless block ~ ~-1 ~ coarse_dirt run fill ~-1 ~-1 ~-1 ~1 ~1 ~1 air replace #french_bread:blocks_with_nutrients_nonsolid
execute if block ~ ~-1 ~ coarse_dirt run fill ~-2 ~-2 ~-2 ~2 ~2 ~2 coarse_dirt replace #french_bread:blocks_with_nutrients
execute if block ~ ~-1 ~ coarse_dirt run fill ~-2 ~-2 ~-2 ~2 ~2 ~2 air replace #french_bread:blocks_with_nutrients_nonsolid

#misc
advancement grant @p only french_bread:faluche/questionable_farming
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:wheat_seeds"}}]