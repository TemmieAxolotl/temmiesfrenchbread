advancement grant @p only french_bread:pain/what_are_we
summon item ~ ~ ~ {Item:{id:"minecraft:netherite_ingot",components:{item_name:{"text":"Shadow Steel","italic":false}}}}
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:resin_brick"}}]
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:diamond"}}]
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:popped_chorus_fruit"}}]
kill @n[type=item,distance=..1,nbt={Item:{id:"minecraft:obsidian"}}]