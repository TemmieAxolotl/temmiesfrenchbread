effect give @s mining_fatigue 3 0
effect give @s slowness 3 0