advancement grant @p only french_bread:croissant/accidental_alloys
advancement grant @p only french_bread:fougasse/lumpy_bars
summon item ~ ~ ~ {Item:{id:"minecraft:iron_ingot",count:2}}
setblock ~ ~ ~ air
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:cauldron"}},limit=1]