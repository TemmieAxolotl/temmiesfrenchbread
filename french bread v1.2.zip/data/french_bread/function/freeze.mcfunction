advancement grant @p only french_bread:fougasse/instant_snow
summon item ~ ~ ~ {Item:{id:"minecraft:powder_snow_bucket"}}
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:water_bucket"}}]