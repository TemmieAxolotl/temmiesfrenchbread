#summon item ~ ~ ~ {Item:{id:"minecraft:iron_nugget",count:5}} not yet lol
advancement grant @p only french_bread:croissant/accidental_alloys
summon item ~ ~ ~ {Item:{id:"minecraft:copper_ingot",count:1}}
setblock ~ ~ ~ minecraft:heavy_weighted_pressure_plate
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:raw_copper"}},limit=1]