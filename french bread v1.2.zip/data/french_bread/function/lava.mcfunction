advancement grant @p only french_bread:croissant/hot_stuff
setblock ~ ~ ~ minecraft:lava_cauldron
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:raw_copper"}},limit=1]