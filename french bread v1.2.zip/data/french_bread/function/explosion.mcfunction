advancement grant @p only french_bread:faluche/manhattan_project
summon creeper ~ ~ ~ {Fuse:1,ignited:1b,CustomName:[{text:"too much pressure"}],ExplosionRadius:15}