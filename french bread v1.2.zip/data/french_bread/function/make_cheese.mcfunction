advancement grant @p only french_bread:croissant/superager
summon item ~ ~ ~ {Item:{id:"minecraft:yellow_dye",components:{item_name:{"text":"Cheese","italic":false},food:{nutrition:5,saturation:2,can_always_eat:1b},consumable:{on_consume_effects:[{type:clear_all_effects}]}}}}
summon item ~ ~ ~ {Item:{id:"minecraft:bucket"}}
setblock ~ ~-1 ~ calcite
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:milk_bucket"}},limit=1]