#handles block explosions
execute at @e[type=item,nbt={Item:{id:"minecraft:creeper_spawn_egg"}}] run function french_bread:explosion

#mob summoning using composter
execute at @e[type=item,nbt={Item:{id:"minecraft:bone_meal"}}] run execute if block ~ ~ ~ minecraft:composter run execute if block ~ ~-1 ~ minecraft:crimson_stem run function french_bread:summon_skele
execute at @e[type=item,nbt={Item:{id:"minecraft:spider_eye"}}] run execute if block ~ ~ ~ minecraft:composter run execute if block ~ ~-1 ~ minecraft:crimson_stem run function french_bread:summon_spdr
execute at @e[type=item,nbt={Item:{id:"minecraft:wheat"}}] run execute if block ~ ~ ~ minecraft:composter run execute if block ~ ~-1 ~ minecraft:clay run function french_bread:summon_cow
execute at @e[type=item,nbt={Item:{id:"minecraft:beetroot"}}] run execute if block ~ ~ ~ minecraft:composter run execute if block ~ ~-1 ~ minecraft:clay run function french_bread:summon_pig
execute at @e[type=item,nbt={Item:{id:"minecraft:beetroot_seeds"}}] run execute if block ~ ~ ~ minecraft:composter run execute if block ~ ~-1 ~ minecraft:clay run function french_bread:summon_birb
execute at @e[type=item,nbt={Item:{id:"minecraft:blaze_powder"}}] run execute if block ~ ~ ~ minecraft:composter run execute if dimension minecraft:the_nether run execute if block ~ ~-1 ~ nether_bricks run function french_bread:summon_blaze
execute at @e[type=item,nbt={Item:{id:"minecraft:snowball"}},predicate=french_bread:is_high_up] run execute if block ~ ~ ~ minecraft:composter run execute if block ~ ~-1 ~ stone run function french_bread:summon_breeze
execute at @e[type=item,nbt={Item:{id:"minecraft:soul_lantern"}}] run execute if block ~ ~ ~ minecraft:composter run execute if block ~ ~-1 ~ minecraft:clay run function french_bread:summon_enderman

#empty cauldron recipes
execute at @e[type=item,nbt={Item:{id:"minecraft:milk_bucket"}}] run execute if block ~ ~ ~ minecraft:cauldron run execute if block ~ ~-1 ~ #minecraft:base_stone_overworld run function french_bread:make_cheese
execute at @e[type=item,nbt={Item:{id:"minecraft:water_bucket"}},predicate=french_bread:is_high_up] run execute if function french_bread:is_in_valid_freezer run execute if block ~ ~ ~ minecraft:cauldron run function french_bread:freeze
execute at @e[type=item,nbt={Item:{id:"minecraft:lime_dye"}},predicate=french_bread:is_high_up] run execute if function french_bread:is_in_valid_freezer run execute if block ~ ~ ~ minecraft:cauldron run function french_bread:cool_paste
execute at @e[type=item,nbt={Item:{id:"minecraft:popped_chorus_fruit"}},predicate=french_bread:is_low_down] run execute if block ~ ~ ~ minecraft:cauldron run execute if entity @e[type=item,nbt={Item:{id:"minecraft:diamond"}},distance=..1] run execute if entity @e[type=item,nbt={Item:{id:"minecraft:obsidian"}},distance=..1] run execute if entity @e[type=item,nbt={Item:{id:"minecraft:resin_brick"}},distance=..1] run execute if function french_bread:is_in_valid_freezer run execute if dimension minecraft:the_end run function french_bread:shadow_steel

#heated cauldron recipes
execute at @e[type=item,nbt={Item:{id:"minecraft:raw_iron"}}] run execute if block ~ ~ ~ minecraft:cauldron run execute if block ~ ~-1 ~ #french_bread:hot_things run function french_bread:raw_iron_melting
execute at @e[type=item,nbt={Item:{id:"minecraft:cauldron"}}] run execute if block ~ ~ ~ minecraft:cauldron run execute if block ~ ~-1 ~ #french_bread:hot_things run function french_bread:cauldron_melting
execute at @e[type=item,nbt={Item:{id:"minecraft:raw_copper"}}] run execute if block ~ ~ ~ minecraft:cauldron run execute if block ~ ~-1 ~ #french_bread:hot_things run function french_bread:raw_copper_melting
execute at @e[type=item,nbt={Item:{id:"minecraft:magma_block"}}] run execute if block ~ ~ ~ minecraft:cauldron run execute if block ~ ~-1 ~ #french_bread:hot_things run function french_bread:lava
execute at @e[type=item,nbt={Item:{id:"minecraft:gray_dye"}}] run execute if entity @e[type=item,nbt={Item:{id:"minecraft:orange_dye"}},distance=..1] run execute if block ~ ~ ~ minecraft:cauldron run execute if block ~ ~-1 ~ #french_bread:hot_things run function french_bread:gunpowder

#filled cauldron recipes
execute at @e[type=item,nbt={Item:{id:"minecraft:bowl"}}] run execute if block ~ ~ ~ minecraft:water_cauldron run execute if block ~ ~-1 ~ #french_bread:hot_things run execute if entity @e[type=item,nbt={Item:{id:"minecraft:lime_dye"}},distance=..1] run execute if entity @e[type=item,nbt={Item:{id:"minecraft:poppy"}},distance=..1] run execute if entity @e[type=item,nbt={Item:{id:"minecraft:dandelion"}},distance=..1] run function french_bread:cook_soup
execute at @e[type=item,nbt={Item:{id:"minecraft:blaze_powder"}}] run execute if block ~ ~ ~ minecraft:powder_snow_cauldron run execute if block ~ ~-1 ~ #french_bread:hot_things run execute if entity @e[type=item,nbt={Item:{id:"minecraft:ender_pearl"}},distance=..1] run execute if entity @e[type=item,nbt={Item:{id:"minecraft:wind_charge"}},distance=..1] run execute if entity @e[type=item,nbt={Item:{id:"minecraft:orange_dye"}},distance=..1] run function french_bread:eye_of_ender
execute at @e[type=item,nbt={Item:{id:"minecraft:lava_bucket"}},predicate=french_bread:is_high_up] run execute if function french_bread:is_in_valid_freezer run execute if block ~ ~ ~ minecraft:powder_snow_cauldron run function french_bread:obsidian

#instant growing
execute at @e[type=item,nbt={Item:{id:"minecraft:wheat_seeds"}}] run execute if block ~ ~ ~ minecraft:farmland run execute if block ~ ~-1 ~ #french_bread:blocks_with_nutrients run function french_bread:instant_grass

#summoning advancements
execute as @a if score @s summons >= one constant run advancement grant @s only french_bread:faluche/youre_a_wizard
execute as @a if score @s summons >= hundred constant run advancement grant @s only french_bread:baguette/witching_hour

#mob buffing
effect give @e[type=#undead] strength 1 0 true
effect give @e[type=creeper] speed 1 0 true
effect give @e[type=#minecraft:sensitive_to_bane_of_arthropods] speed 1 1 true

#misc
clear @a minecraft:elytra[minecraft:damage=16]
clear @a #copper_chests
execute at @e[type=copper_golem] run fill ~ ~-1 ~ ~ ~-1 ~ air replace #minecraft:copper_chests destroy
recipe give @a *
execute as @a run execute run attribute @s minecraft:max_health base set 16
kill @e[type=villager]
execute as @e[type=!skeleton,predicate=french_bread:is_on_soul_sand] run execute at @s run tp ~ ~-1 ~
execute as @e[type=!skeleton,predicate=french_bread:is_on_soul_blocks] run function french_bread:soul_effects
execute as @e[type=!piglin,type=!hoglin,type=!piglin_brute,type=!pig,type=!zombified_piglin,predicate=french_bread:is_on_nether_ground] run effect give @s wither 3 1
execute as @e[type=!item,type=!#arrows,predicate=french_bread:is_on_stonecutter] run function french_bread:entity_cutting
execute at @e[type=item,nbt={Item:{id:"minecraft:lantern"}}] run execute if block ~ ~-1 ~ soul_sand run function french_bread:haunt_lantern
execute as @a[predicate=french_bread:is_on_end_blocks] run effect give @s blindness 2 0
execute as @a[predicate=french_bread:is_low_down] run advancement grant @s only french_bread:pain/exit_the_enter
execute as @a[predicate=french_bread:is_very_high_up] run advancement grant @s only french_bread:baguette/welcome_to_space
advancement grant @a[advancements={french_bread:baguette/uta_tribute=true,french_bread:baguette/tei_tribute=true,french_bread:baguette/gumi_tribute=true,french_bread:baguette/off_camera_mining=true,french_bread:baguette/i_am_healthcare=true,french_bread:baguette/next_generation=true,french_bread:baguette/paste_master=true,french_bread:baguette/true_epicness=true,french_bread:baguette/twinks_on_tour=true,french_bread:baguette/welcome_to_space=true,french_bread:baguette/witching_hour=true,french_bread:baguette/peak_game_design=true}] only french_bread:baguette/teto_certified