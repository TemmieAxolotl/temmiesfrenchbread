advancement grant @p only french_bread:fougasse/reaper_of_souls
summon item ~ ~ ~ {Item:{id:"minecraft:soul_lantern",count:1}}
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:lantern"}},limit=1]