execute at @s run damage @s 15 minecraft:sting
advancement grant @s only french_bread:croissant/workshops_most_feared