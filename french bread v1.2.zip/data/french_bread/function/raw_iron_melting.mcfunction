advancement grant @p only french_bread:croissant/accidental_alloys
summon item ~ ~ ~ {Item:{id:"minecraft:iron_ingot",count:1}}
setblock ~ ~ ~ minecraft:heavy_weighted_pressure_plate
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:raw_iron"}},limit=1]