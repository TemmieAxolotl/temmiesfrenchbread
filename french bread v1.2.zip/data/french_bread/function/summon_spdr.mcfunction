summon spider ~ ~ ~
setblock ~ ~-1 ~ coarse_dirt
scoreboard players add @p summons 1
advancement grant @p only french_bread:faluche/raising_the_dead
kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:spider_eye"}}]